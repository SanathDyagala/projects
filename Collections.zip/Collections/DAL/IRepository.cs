﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public interface IRepository<T>
    {
        void AddEmployee(T employee);
        void UpdateEmployee(int emplId, string FirstName, string LastName, int salary, DateTime dateofjoining);
        void DeleteEmployee(int emplId);
        List<T> GetAllEmployees();
        T GetEmployeeById(int emplId);
        void AddToFile(List<T> employees);
        List<T> ReadFromFile();
    }
}
