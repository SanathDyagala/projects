﻿using EntityClassesLib;

namespace DAL
{
    public class CollectionRepo : IRepository<Employee>
    {
        private List<Employee> employees;
        private string filePath = @"C:\collections\collections.txt";


        private int employeeId;

        public CollectionRepo()
        {
            employees = new List<Employee>();
        }
        public void AddEmployee(Employee employee)
        {
            employees.Add(employee);
        }

        public void AddToFile(List<Employee> employees)
        {
            if (employees.Count > 0)
            {
                using (StreamWriter sw = File.AppendText(filePath))
                {
                    foreach (Employee employee in employees)
                    {
                        string empDetails = string.Format("{0},{1},{2},{3},{4}", employee.EmployeeID, employee.FirstName, employee.LastName, employee.Salary, employee.DateofJoining);
                        sw.WriteLine(empDetails);
                    }
                }
                Console.WriteLine("Employee records added to file successfully!");
                Console.ReadKey();
            }
            else
            {
                Console.WriteLine("No employee records found to add to file.");
                Console.ReadKey();
            }
        }

        public void DeleteEmployee(int employeeId)
        {
            Employee employee = employees.Find(e => e.EmployeeID == employeeId);
            if (employee != null)
            {
                employees.Remove(employee);
            }
        }

        public List<Employee> GetAllEmployees()
        {
            return employees;
        }

        public Employee GetEmployeeById(int employeeId)
        {
            return employees.FirstOrDefault(e => e.EmployeeID == employeeId);
        }

        public List<Employee> ReadFromFile()
        {
            List<Employee> employees = new List<Employee>();
            using (StreamReader reader = new StreamReader("EmployeesCollection.txt"))
            {
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    string[] values = line.Split(',');
                    int employeeId = int.Parse(values[0]);
                    string firstName = values[1];
                    string lastName = values[2];
                    int salary = int.Parse(values[3]);
                    DateTime dateofjoining = DateTime.Parse(values[4]);
                    employees.Add(new Employee { EmployeeID = employeeId, FirstName = firstName, LastName = lastName, Salary = salary, DateofJoining = dateofjoining });
                }
                return employees;
            }
        }

        public void UpdateEmployee(int emplId, string FirstName, string LastName, int salary, DateTime dateofjoining)
        {
            Employee emp = employees.Find(e => e.EmployeeID == employeeId);
            if (emp != null)
            {
                emp.FirstName = FirstName;
                emp.LastName = LastName;
                emp.Salary = salary;
                emp.DateofJoining = dateofjoining;
            }

        }

        public void UpdateEmployee(int empid, Employee modifiedemployee)
        {
            throw new NotImplementedException();
        }

        public void PersistData()
        {
           
        }

        public void ReadData()
        {
           
        }
    }
}