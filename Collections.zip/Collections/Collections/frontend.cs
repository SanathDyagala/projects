﻿using DAL;
using EntityClassesLib;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Human_Collections
{
    public class FrontEnd
    {
        public static void Main()
        {
            CollectionRepo repository = new CollectionRepo();

            List<int> empid = new List<int>();

            List<string> firstname = new List<string>();

            List<string> lastname = new List<string>();

            List<int> salary = new List<int>();
            List<DateTime> date = new List<DateTime>();


            // Add an Employee.

           
            Employee employee1 = new Employee
            {
                EmployeeID = 1,
                FirstName = "Wahed",
                LastName = "Ali",
                Salary = 50000,
                DateofJoining = new DateTime(2020, 1, 1)
            };
            repository.AddEmployee(employee1);

            // Update an Existing Employee.
            repository.UpdateEmployee(1, "sanath", "Dyagala", 55000, new DateTime(2020, 1, 15));


            // Delete an existing employee
            repository.DeleteEmployee(1);


            // Display all employees
            List<Employee> allEmployees = repository.GetAllEmployees();

            foreach (Employee employee in allEmployees)
            {
                Console.WriteLine("Employee ID: {0}, FirstName: {1}, LastName: {2}, salary :{3} , DOJ {4}",
                    employee.EmployeeID, employee.FirstName, employee.LastName, employee.Salary, employee.DateofJoining);
            }

            Console.ReadLine();

            // Display a single employee by ID
            Employee singleEmployee = repository.GetEmployeeById(2);
            if (singleEmployee != null)
            {
                Console.WriteLine("Employee ID: {0}, FirstName: {1}, LastName: {2}, salary :{3} , DOJ :{4}",
                    singleEmployee.EmployeeID, singleEmployee.FirstName, singleEmployee.LastName, singleEmployee.Salary, singleEmployee.DateofJoining);
            }
            Console.ReadLine();

            // Add employee records to file
            List<Employee> employeesToAdd = new List<Employee>();
            employeesToAdd.Add(new Employee { EmployeeID = 1, FirstName = "John", LastName = "Doe", Salary = 20000, DateofJoining = new DateTime(2020, 11, 23) });
            employeesToAdd.Add(new Employee { EmployeeID = 2, FirstName = "Jane", LastName = "Doe", Salary = 10000, DateofJoining = new DateTime(2018, 01, 21) });


        }
    }
}
