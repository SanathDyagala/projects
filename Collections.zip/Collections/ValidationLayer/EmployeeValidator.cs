﻿using EntityClassesLib;
using System.Text.RegularExpressions;

namespace ValidationLayer
{
    public class EmployeeValidator
    {

        //FirstName and LastName are mandatory.
        public static bool IsValid(string str)
        {
            Regex a = new Regex(@"^\d{1,7}$");
            bool temp = true;

            if (string.IsNullOrEmpty(str) || a.IsMatch(str.ToString()))
            {
                temp = false;
            }
            return temp;
        }

        //DateOfJoining cannot be greater than current date.
        public static bool DateValidate(DateTime dt)
        {
            bool temp = true;
            if (dt > DateTime.Now)
                temp = false;
            return temp;
        }

        //// FirstName and LastName can contain only characters
        //if (!Regex.IsMatch(employee.FirstName, @"^[a-zA-Z]+$") || !Regex.IsMatch(employee.LastName, @"^[a-zA-Z]+$"))
        //    return false;

        //// DateOfJoining cannot be greater than current date
        //if (employee.DateofJoining > DateTime.Now)
        //    return false;

        //return true;
    }



}