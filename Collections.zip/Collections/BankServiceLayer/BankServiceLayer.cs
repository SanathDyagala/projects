﻿using DAL;
using EntityClassesLib;

namespace BankServiceLayer
{
    public class BankServiceLayer
    {
        private CollectionRepo dal = new CollectionRepo();

        public List<Employee> HttpGetAllEmployees()
        {
            return this.dal.GetAllEmployees();
        }
        public void HttpPostEmployee(Employee newemployee)
        {
            this.dal.AddEmployee(newemployee);
        }
        public void PutEmployee(int emplId, string FirstName, string LastName, int salary, DateTime dateofjoining)
        {
            this.dal.UpdateEmployee(emplId, FirstName,LastName,salary,dateofjoining);
        }
        public void DeleteEmployee(int empid)
        {
            this.dal.DeleteEmployee(empid);
        }
        public void AddEmployeeToFile()
        {
            List<Employee> temp = dal.GetAllEmployees();
            dal.AddToFile(temp);
        }

        public void DisplayEmployeeFromFile()
        {
            List<Employee> tmp = dal.GetAllEmployees();
            dal.ReadFromFile();
        }

        public Employee GetEmployeeById(int empid) => this.dal.GetEmployeeById(empid);

        public void PersistData()
        {
            this.dal.PersistData();
        }

        public void ReadData()
        {
            this.dal.ReadData();
        }



    }
}