﻿using System.IO;
using DAL;
namespace LoggerLib
{
    public class FileLogger : ILogger
    {
        public StreamWriter? sw = null;
        CollectionRepo dal = new CollectionRepo();
        public void Log(string message = "")
        {

            //use File I/O APIs here
            //check if file named"EmployeeRecords.txt exist in the folder named "EmployeeRecords"

            if (!Directory.Exists("c:\\EmployeesCollection"))
            {
                Directory.CreateDirectory("c:\\EmployeesCollection");
                Console.WriteLine("Directory created for EmployeesCollection");
            }
            else
            {
                Console.WriteLine("Directory already exists for EmployeesCollection");
            }
            //check if a file named logs.txt exists in the c:\logs folder

            FileInfo fi = new FileInfo("c:\\EmployeesCollection\\EmployeesCollection.txt");

            if (!fi.Exists)
            {
                fi.Create();
                Console.WriteLine("File created for writing EmployeesCollection");
            }
            else
            {
                Console.WriteLine("File already exists for writing EmployeesCollection");

            }
            sw = new StreamWriter("c:\\EmployeesCollection\\EmployeesCollection.txt", true);  //opens the file in append mode

            //write the EmployeesCollection into the file

            sw.WriteLine("{0} written at {1}", message, DateTime.Now.ToLongTimeString());
        }

        public void Dispose()
        {
            //write code to close the file
            if (this.sw != null)
            {
                sw.Close();
                Console.WriteLine("EmployeesCollection file closed in Dispose()");
            }
        }
    }
}

