﻿using Dep.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dep
{
    public class EmployeeRepository : IEmployeeRepository
    {
        private readonly PIP_dbContext _context;
        public EmployeeRepository(PIP_dbContext context)
        {
            _context = context;
        }

        public void AddEmployee(Employee employee)
        {
            _context.Employees.Add(employee);
            _context.SaveChanges();
        }

        public void UpdateEmployee(Employee employee)
        {
            _context.Employees.Update(employee);
            _context.SaveChanges();
        }

        public void DeleteEmployee(Employee employee)
        {
            _context.Employees.Remove(employee);
            _context.SaveChanges();
        }

        public List<Employee> GetAllEmployees()
        {
            return _context.Employees.ToList();
        }

        public List<Department> GetDepartmentsWithEmployeesEagerLoading()
        {
            return _context.Departments.Include(d => d.Employees).ToList();
        }

        public List<Department> GetDepartmentsWithEmployeesLazyLoading()
        {
            return _context.Departments.ToList();
        }

        public Employee GetEmployeeById(int employeeId)
        {
            return _context.Employees.Find(employeeId);
        }

        public List<Employee> GetEmployees()
        {
            return _context.Employees.ToList();
        }

        public List<Employee> GetEmployeesByDepartment(int departmentid)
        {
            return _context.Employees
            .Where(e => e.Department.DepartmentId == departmentid)
            .ToList();
        }

        public Department GetDepartmentById(int departmentId)
        {
            return _context.Departments.SingleOrDefault(d => d.DepartmentId == departmentId);
        }

        public void Quit()
        {
            throw new NotImplementedException();
        }

    }
        
        


}
