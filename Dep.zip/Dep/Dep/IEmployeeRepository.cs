﻿using Dep.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dep
{
    public interface IEmployeeRepository
    {
        void AddEmployee(Employee employee);
        void UpdateEmployee(Employee employee);
        void DeleteEmployee(Employee employee);
        List<Employee> GetAllEmployees();
        Employee GetEmployeeById(int employeeId);
        List<Department> GetDepartmentsWithEmployeesEagerLoading();
        List<Department> GetDepartmentsWithEmployeesLazyLoading();
        List<Employee> GetEmployees();
        List<Employee> GetEmployeesByDepartment(int departmentid);
        public Department GetDepartmentById(int departmentId);

        public void Quit();
    }
}
