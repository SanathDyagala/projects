﻿using System;
using System.Linq;
using Dep.Models;
using Dep;
using Microsoft.EntityFrameworkCore;
using System.Security.Cryptography.X509Certificates;

namespace Dep
{
    class Program
    {
        static PIP_dbContext context = new PIP_dbContext();
        private static void Main(string[] args)
        {
            
            

            // create an instance of the repository
            //var employeeRepository = new EmployeeRepository(context);

            int choice = -1;
            do
            {
                Console.Clear();
                Console.WriteLine("1. ADD A NEW EMPLOYEE");
                Console.WriteLine("2. EDIT EMPLOYEE DETAILS");
                Console.WriteLine("3. DELETE A EMPLOYEE");
                Console.WriteLine("4. GET ALL EMPLOYEES");
                Console.WriteLine("5. GET SINGLE RECORD BY ID");
                Console.WriteLine("6. LOAD DETAILS BY EAGER");
                Console.WriteLine("7. LOAD DETAILS BY LAZY");
                Console.WriteLine("8.DETAILS USING LINQ");
                Console.WriteLine("9. DETAILS USING JOIN");
                Console.WriteLine("10. QUIT");

                Console.Write("\nEnter your choice (1-10): ");
                choice = int.Parse(Console.ReadLine());

                //you can use a switch or if else to check the choice
                switch (choice)
                {
                    case 1:
                        Add();
                        break;
                    case 2:
                        update();
                        break;
                    case 3:
                        Delete();
                        break;
                    case 4:
                        AllEmp();
                        break;
                    case 5:
                        single();
                        break;
                    case 6:
                        eager();
                        break;
                    case 7:
                        Lazy();
                        break;
                    case 8:
                        linq();
                        break;
                    case 9:
                        join();
                         break;
                    case 10:
                        
                        Console.WriteLine("Thank You visit Again..!!!");
                       
                        Quit();
                        break;

                    default:
                        Console.WriteLine("Invalid Choice.Press any key to continue");
                        Console.ReadKey();
                        break;
                }



            } while (choice != 11);



            // add a new employee
              void Add()
            {
               
                var employeeRepository = new EmployeeRepository(context);

               

                Console.Write("Enter Employee FirstName: ");
                string FirstName = Console.ReadLine();

                Console.Write("Enter Employee LastName: ");
                string LastName = Console.ReadLine();

                Console.Write("Enter Employee salary: ");
                decimal Salary = decimal.Parse(Console.ReadLine());

                Console.WriteLine("Enter Employee DateofJoining");
                DateTime DateOfJoining = DateTime.Parse(Console.ReadLine());

                Console.WriteLine("Enter Employee DepartmentId 1:Sales ,2:Marketing ,3:Engineering");
                int DepartmentId =Convert.ToInt32( Console.ReadLine());

                Employee newEmployee = new Employee()
                {
                    FirstName = FirstName,
                    LastName = LastName,
                    Salary = Salary,
                    DateOfJoining = DateOfJoining,  
                    DepartmentId = DepartmentId


                };

                //Department department = EmployeeRepository.GetDepartmentById(departmentId);

                //if (department == null)
                //{
                //    Console.WriteLine($"Department '{departmentId}' not found.");
                //    return;
                //}


                employeeRepository.AddEmployee(newEmployee);

            }

            // update an existing employee
             void update()
            {
                var employeeRepository = new EmployeeRepository(context);
                Console.Write("Enter Employee Id ");
                int Id = int.Parse(Console.ReadLine());
                var existingEmployee = employeeRepository.GetEmployeeById(Id);
                if (existingEmployee != null)
                {
                    Console.Write("Enter Employee FirstName: ");
                    string FirstName = Console.ReadLine();

                    Console.Write("Enter Employee LastName: ");
                    string LastName = Console.ReadLine();

                    Console.Write("Enter Employee salary: ");
                    decimal Salary = decimal.Parse(Console.ReadLine());

                    Console.WriteLine("Enter Employee DateofJoining");
                    DateTime DateOfJoining = DateTime.Parse(Console.ReadLine());

                    Console.WriteLine("Enter Employee DepartmentId 1:Sales ,2:Marketing ,3:Engineering");
                    int DepartmentId = Convert.ToInt32(Console.ReadLine());

                    existingEmployee.FirstName = FirstName;
                    existingEmployee.LastName = LastName;
                    existingEmployee.Salary = Salary;
                    existingEmployee.DateOfJoining = DateOfJoining;
                    existingEmployee.DepartmentId = DepartmentId;

                    employeeRepository.UpdateEmployee(existingEmployee);

                }

                
            }

            // delete an Deleting employee
             void Delete()
            {
                var employeeRepository = new EmployeeRepository(context);
                Console.Write("Enter Employee Id ");
                int Id = int.Parse(Console.ReadLine());
                var employeeToDelete = (employeeRepository.GetEmployeeById(Id));
                employeeRepository.DeleteEmployee(employeeToDelete);
            }

            // display all employees
             void AllEmp()
            {
                var employeeRepository = new EmployeeRepository(context);
                var allEmployees = employeeRepository.GetAllEmployees();
                Console.WriteLine("All Employees:");
                foreach (var employee in allEmployees)
                {
                    Console.WriteLine($"ID: {employee.EmployeeId}, Name: {employee.FirstName} {employee.LastName}, Salary: {employee.Salary}, Date Of Joining: {employee.DateOfJoining},Department :{employee.DepartmentId}");
                }
                Console.ReadKey();
            }
           
            

            // display a single employee record using EmployeeID
             void single()
            {
                var employeeRepository = new EmployeeRepository(context);
                Console.Write("Enter Employee Id ");
                int Id = int.Parse(Console.ReadLine());
                var employeeById = employeeRepository.GetEmployeeById(Id);
                Console.WriteLine($"Employee with ID :{employeeById.EmployeeId}, Name: {employeeById.FirstName} {employeeById.LastName}, Salary: {employeeById.Salary}, Date Of Joining: {employeeById.DateOfJoining},Department :{employeeById.DepartmentId}");
                Console.ReadKey();
            }

            

            // load the departments and then load employees working in those departments using eager loading

            void eager()
            {

                var departmentsWithEmployeesEager = context.Departments.Include(d => d.Employees);
                Console.WriteLine("Departments with Employees (Eager Loading):");
                foreach (var department in departmentsWithEmployeesEager)
                {
                    Console.WriteLine($"{department.DepartmentName}:");
                    foreach (var employee in department.Employees)
                    {
                        Console.WriteLine($"- {employee.FirstName} {employee.LastName} {employee.Salary} {employee.DateOfJoining}{employee.DepartmentId}");
                    }
                }
                Console.ReadKey();
            }


            // load the departments and then load employees working in those departments using lazy loading
             void Lazy()
            {
                using (var context = new PIP_dbContext())
                {
                    // Load departments lazily
                    var departments = context.Departments.ToList();

                    // Loop through departments and load employees for each department lazily
                    foreach (var department in departments)
                    {
                        Console.WriteLine($"Department Name: {department.DepartmentName}");

                        foreach (var employee in department.Employees)
                        {
                            Console.WriteLine($"\t - {employee.FirstName} {employee.LastName} {employee.Salary} {employee.DateOfJoining}{employee.DepartmentId}");
                        }
                    }
                    Console.ReadKey();
                }
            }

            //void Lazy()
            //{
            //    var departmentsWithEmployeesLazy = context.Departments.ToList();
            //    Console.WriteLine("Departments with Employees (Lazy Loading):");
            //    foreach (var department in departmentsWithEmployeesLazy)
            //    {
            //        Console.WriteLine($"{department.DepartmentName}:");
            //        foreach (var employee in department.Employees)
            //        {
            //            Console.WriteLine($"- {employee.FirstName} {employee.LastName} {employee.Salary} {employee.DateOfJoining}{employee.DepartmentId}");
            //        }
            //    }
            //    Console.ReadKey();
            //}



            // display EmployeeId, FirstName, LastName, Salary from Employees using LINQ to EF Core
            void linq()
            {
                var employeeRepository = new EmployeeRepository(context);
                var employeesProjection = employeeRepository.GetAllEmployees().Select(e => new { e.EmployeeId, e.FirstName, e.LastName, e.Salary });
                Console.WriteLine("Employees Projection:");
                foreach (var employee in employeesProjection)
                {
                    Console.WriteLine($"ID: {employee.EmployeeId}, Name: {employee.FirstName} {employee.LastName}, Salary: {employee.Salary}");
                }
                Console.ReadKey();
            }
           

            // display employees working in departments using inner join

            void join()
            {
                var employeesInDepartments = context.Departments.Join(
                context.Employees,
                department => department.DepartmentId,
                employee => employee.DepartmentId,
                (department, employee) => new { Department = department.DepartmentName, Employee = employee.FirstName + " " + employee.LastName }
            );
                Console.WriteLine("Employees Working in Departments (Inner Join):");
                foreach (var employee in employeesInDepartments)
                {
                    Console.WriteLine($"{employee.Employee} works in {employee.Department}");
                }
                Console.ReadKey();
            }

            void Quit()
            {
                var employeeRepository = new EmployeeRepository(context);
                employeeRepository.Quit();
            }
        }
    }
}
