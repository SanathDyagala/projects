namespace EntityClassesLib
{
    public struct CustomerAddress
    {
        public string City { get; set; }
         public string State { get; set; }
    }

}
