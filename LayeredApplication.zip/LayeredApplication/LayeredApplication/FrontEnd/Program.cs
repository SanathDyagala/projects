﻿using bl;

namespace FrontEnd
{
    class Program
    {
        static BusinessLogic bl =new BusinessLogic();
        static bool IsDataRetrived = new bool();
        static void Main()
        {
            
            //display a menu
             int choice = -1;

            do

            {

                Console.Clear();        //clear the screen

                Console.WriteLine("1. GET ALL CUSTOMERS");

                Console.WriteLine("2. ADD A NEW CUSTOMER");

                Console.WriteLine("3. EDIT CUSTOMER DETAILS");

                Console.WriteLine("4. REMOVE A CUSTOMER");

                Console.WriteLine("5. Quit");

                if (IsDataRetrived == false)
                {
                    bl.ReadData();
                    IsDataRetrived = true;
                }

                Console.Write("\nEnter your choice (1-5): ");

                choice = int.Parse(Console.ReadLine());

            //by uing switch case 
            switch(choice)
                {
                    case 1:
                            GetAllCustomers();
                            break;
                    case 2:
                            AddCustomer();
                            break;
                    case 3:
                            EditCustomer();
                            break;
                    case 4:
                            DeleteCustomer();
                            break;
                    case 5:
                            bl.PersistData();
                            Console.WriteLine("Thank you for using Simple CMS");
                            break;
                    default:
                            Console.WriteLine("Invalid choice. Press a key to continue");
                            Console.ReadKey();
                            break;
                }
            } while(choice != 5);
        }
        static void GetAllCustomers()

        {
               Console.Clear();
                var result = bl.ObtainAllCustomerList();
                if(result.Count() == 0)
                {
                    Console.WriteLine("No customers to show");
                }
                else
                {
                    foreach(var customer in bl.ObtainAllCustomerList())
                    {
                        Console.WriteLine(customer);
                    }
                }
                Console.ReadKey();
        }

        static void AddCustomer()

        {
            Console.Clear();
            //input customer details
            Console.Write("Enter customer id: ");
            int cid = int.Parse(Console.ReadLine());

            Console.Write("Enter customer name: ");
            string cname = Console.ReadLine();

            Console.Write("Enter customer city: ");
            string city = Console.ReadLine();

            Console.Write("Enter customer state: ");
            string state = Console.ReadLine();

            bl.InsertCustomer(cid,cname,city,state);
        }

        static void EditCustomer()



        {

            Console.WriteLine("Enter Customer ID:");

            int cid = int.Parse(Console.ReadLine());

            Console.Write("Enter customer newname: ");

            string newname = Console.ReadLine();

            Console.Write("Enter customer newcity: ");

            string newcity = Console.ReadLine();

            Console.Write("Enter customer newstate: ");

            string newstate = Console.ReadLine();

            bl.ModifyCustomer(cid,newname,newcity,newstate);

         

            Console.ReadKey();




        }



        static void DeleteCustomer()
        {
            Console.WriteLine("Enter Customer ID:");
            int cid=int.Parse(Console.ReadLine());
            Console.WriteLine("Are you sure to Delete?\n Press 1 to remove customer\n Press 0 to abort");
            int del=int.Parse(Console.ReadLine());
            if(del==1){
                 bl.RemoveCustomer(cid);
            }
            Console.ReadKey();
        }

       
    }
}
