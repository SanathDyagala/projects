﻿using DAL;
using EntityClassesLib;
namespace BankServiceLayer
{   
    public class BankServiceLayer
    {
            private CustomerCollectionRepo dal=new CustomerCollectionRepo();


       public List<Customer>HttpGetAllCustomers()
       {
            return this.dal.GetAllCustomers();
       } 
        public void HttpPostCustomer(Customer newcustomer)
        {
            this.dal.AddNewCustomer(newcustomer);
        }
        public void PutCustomer(int custid, Customer modifiedcustomer)
        {
            this.dal.EditCustomer(custid, modifiedcustomer);
        }
        public void DeleteCustomer(int custid)
        {
            this.dal.DeleteCustomer(custid);
         }

        public void PersistData()
        {
            this .dal.PersistData();
        }

        public void ReadData() 
        {
            this .dal.ReadData();   
        }

}

}