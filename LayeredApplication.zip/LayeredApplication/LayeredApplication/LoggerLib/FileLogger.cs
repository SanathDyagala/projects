﻿using System.IO;
namespace LoggerLib
{
    public class FileLogger : ILogger
    {
        public StreamWriter sw=null;
         public void Log(string message="")
        {

            //use File I/O APIs here
            //check if file named"log.txt exist in the folder named "logs"
            // DirectoryInfo d=new DirectoryInfo("c:\\logs");
            // if(!d.Exists){
            //     d.Create();
            //     Console.WriteLine("Directory created for logs");
            // }
            // else
            // {
            //     Console.WriteLine("Directory already exists for logs");
            // }
            if(! Directory.Exists("c:\\logs"))
            {
                Directory.CreateDirectory("c:\\logs");
                Console.WriteLine("Directory created for logs");
            }
            else
            {
                Console.WriteLine("Directory already exists for logs");
            }
            //check if a file named logs.txt exists in the c:\logs folder

            FileInfo fi = new FileInfo("c:\\logs\\log.txt");

            if(! fi.Exists)
            {
                fi.Create();
                Console.WriteLine("File created for writing logs");
            }
            else
            {
                Console.WriteLine("File already exists for writing logs");

            }
            sw=new StreamWriter("c:\\logs\\log.txt",true);  //opens the file in append mode
            //write the log into the file
            sw.WriteLine("{0} written at {1}",message,DateTime.Now.ToLongTimeString());
        }
        
        public void Dispose()
        {
            //write code to close the file
            if(this.sw!=null)
            {
                    sw.Close();
                Console.WriteLine("Log file closed in Dispose()");
            }
        }
    }
}

