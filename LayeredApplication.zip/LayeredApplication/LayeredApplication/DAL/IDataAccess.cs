using EntityClassesLib;
namespace DAL
{
    public interface IDataAccess
    {
        List<Customer> GetAllCustomers();
        void AddNewCustomer(Customer c);
        void EditCustomer(int customerid, Customer c);
        void DeleteCustomer(int customerid);

        void PersistData();

        void ReadData();
    }
}