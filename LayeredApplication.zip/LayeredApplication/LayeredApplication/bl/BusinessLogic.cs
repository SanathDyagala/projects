﻿using EntityClassesLib;

using BankService=BankServiceLayer.BankServiceLayer;
using LoggerLib;
using System.Text;



namespace bl

{

 

public class BusinessLogic
        {

            private BankService bsl =new BankService();
            private FileLogger fileLogger =new FileLogger();

            public List<RevisedCustomer> ObtainAllCustomerList()

            {
                this.fileLogger.Log("ObtainAllCustomers() called at: " +DateTime.Now);
                this.fileLogger.Dispose();
                List<Customer> customers = bsl.HttpGetAllCustomers();

                List<RevisedCustomer> result = new List<RevisedCustomer>();

                foreach(Customer cm in customers)

                {

                   RevisedCustomer rc = new RevisedCustomer();

                   rc.CID = cm.CustomerId;

                   rc.CName = cm.CustomerName.ToUpper();

                   rc.Address = cm.Address.City +" " +cm.Address.State;

                   result.Add(rc);

                }

                return result;



            }

            public void InsertCustomer(int cid, string cname, string city, string state)
            {

                this.fileLogger.Log("InsertCustomer() called at: " +DateTime.Now);
                this.fileLogger.Dispose();
                Customer c = new Customer();
                c.CustomerId = cid;
                c.CustomerName = cname;
                CustomerAddress ca = new CustomerAddress();
                ca.City = city;
                ca.State = state;
                c.Address = ca;
                bsl.HttpPostCustomer(c);
            }

            public void PersistData()
        {
            this.bsl.PersistData();
        }

          public void ReadData()
        {
            this.bsl.ReadData();    
        }
            
            public void ModifyCustomer(int cid, string newname, string newcity, string newstate)
            {
                this.fileLogger.Log("ModifyCustomer() called at:" +DateTime.Now);
                this.fileLogger.Dispose();
                Customer c=new Customer();
                c.CustomerId=cid;
                c.CustomerName=newname;
               CustomerAddress ca = new CustomerAddress();
                ca.City = newcity;
                ca.State = newstate;
                c.Address = ca;
                bsl.PutCustomer(cid,c);
            }



            public void RemoveCustomer(int cid)
            {
                    this.fileLogger.Log("RemoveCustomer() called at:" +DateTime.Now);
                    this.fileLogger.Dispose();
                    Customer c=new Customer();
                    c.CustomerId=cid;
                    bsl.DeleteCustomer(cid);
            }
        }

            public class RevisedCustomer

            {

                public int CID { get; set; }

                public string CName { get; set; }

                public string Address { get; set; }



                public override string ToString()

                {

                    //string details = this.CID.ToString();
                    //details += ", " +this.CName;
                    //details += ", " +this.Address;         // += is a bad usage of coding
                    //return details;



                    // use StringBuilder for better performance
                    StringBuilder sb = new StringBuilder();
                    sb.Append("Customer Id:" +this.CID);
                    sb.Append("\nCustomer Name:" +this.CName);
                    sb.Append("\nCustomer City & State:" +this.Address);
                    return sb.ToString();
                }
            }
}