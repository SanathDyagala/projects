﻿using CoreWebApiEF.Models;
using Microsoft.EntityFrameworkCore;

namespace CoreWebApiEF
{
    public class EmployeeRepository : IEmployeeRepository
    {
        private readonly PIPDB2Context _context;

        public EmployeeRepository(PIPDB2Context context)
        {
            _context = context;
        }

        public IEnumerable<Employee> GetEmployees()
        {
            return _context.Employees.ToList();
        }

        public Employee GetEmployeeById(int id)
        {
            return _context.Employees.FirstOrDefault(e => e.EmployeeId == id);
        }

        public void AddEmployee(Employee employee)
        {
            _context.Employees.Add(employee);
            _context.SaveChanges();
        }

        public void EditEmployee(Employee employee)
        {
            _context.Entry(employee).State = EntityState.Modified;
            _context.SaveChanges();
        }

        public void DeleteEmployee(int id)
        {
            var employee = _context.Employees.Find(id);
            _context.Employees.Remove(employee);
            _context.SaveChanges();
        }

        public IEnumerable<Employee> GetEmployeesByDepartmentId(int departmentId)
        {
            return _context.Employees.Where(e => e.DepartmentId == departmentId).ToList();
        }

    }
}
