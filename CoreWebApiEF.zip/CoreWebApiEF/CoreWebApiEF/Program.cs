using CoreWebApiEF;
using CoreWebApiEF.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Cors;
//using Microsoft.Extensions.Configuration;

//internal class Program
//{
//    public static IConfiguration Configuration { get; }� //to read the values from appsettings.json file.
//    private static void Main(string[] args)
//    {
//        var builder = WebApplication.CreateBuilder(args);


//        // Add services to the container.

//        builder.Services.AddControllers();

//        //  builder.Services.AddSingleton<IEmployeeRepository, EmployeeRepository>();

//        //builder.Services.AddDbContext<PIPDB2Context>(item => item.UseSqlServer
//        //(builder.Configuration.GetConnectionString("ConnStr")),
//        //ServiceLifetime.Scoped);


//        // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
//        builder.Services.AddEndpointsApiExplorer();

//        //////


//        builder.Services.AddSwaggerGen();

//        var app = builder.Build();

//        //builder.Services.AddCors(option => option.AddPolicy("AllowOrigin",
//        //policy =>
//        //{
//        // policy.WithOrigins("https://localhost:7196/");
//        //})
//        //);



//        // Configure the HTTP request pipeline.
//        if (app.Environment.IsDevelopment())
//        {
//            app.UseSwagger();
//            app.UseSwaggerUI();
//        }

//        app.UseHttpsRedirection();

//        app.UseRouting();

//        app.UseCors("AllowOrigin");

//        app.UseAuthorization();

//        app.MapControllers();

//        app.Run();
//    }
//}



//using Microsoft.EntityFrameworkCore;

internal class Program
{
    public static IConfiguration Configuration { get; }� //to read the values from appsettings.json file.
    private static void Main(string[] args)
    {
        var builder = WebApplication.CreateBuilder(args);


        // Add services to the container.
        builder.Services.AddCors(option => option.AddPolicy("AllowOrigin",
       build =>
       {
           build.WithOrigins("http://localhost:4200").AllowAnyMethod().AllowAnyHeader();
       })
      );

        builder.Services.AddControllers();

        builder.Services.AddScoped<IEmployeeRepository, EmployeeRepository>();

        ////Added for database connection------
        builder.Services.AddDbContext<PIPDB2Context>(item => item.UseSqlServer
        (builder.Configuration.GetConnectionString("ConnStr")));

        // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
        builder.Services.AddEndpointsApiExplorer();
        builder.Services.AddSwaggerGen();

        var app = builder.Build();
       
        

        

        // Configure the HTTP request pipeline.
        if (app.Environment.IsDevelopment())
        {
            app.UseSwagger();
            app.UseSwaggerUI();
        }

        app.UseHttpsRedirection();

        app.UseRouting();

        app.UseCors("AllowOrigin");

        app.UseAuthorization();

        app.MapControllers();

        app.Run();
    }
}