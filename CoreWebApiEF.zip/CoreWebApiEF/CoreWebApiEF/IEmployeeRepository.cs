﻿using CoreWebApiEF.Models;

namespace CoreWebApiEF
{
    public interface IEmployeeRepository
    {
        IEnumerable<Employee> GetEmployees(); 
        Employee GetEmployeeById(int id); 
        void AddEmployee(Employee employee);
        void EditEmployee(Employee employee); 
        void DeleteEmployee(int id);
        IEnumerable<Employee> GetEmployeesByDepartmentId(int departmentId);
    }
}
