﻿using CoreWebApiEF.Models;
using Microsoft.AspNetCore.Mvc;

namespace CoreWebApiEF.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : Controller
    {
        private readonly IEmployeeRepository repository;
        public EmployeeController(IEmployeeRepository repo)
        {
            repository = repo;
        }
        [HttpGet] 
        public IActionResult GetEmployees()
        { 
            var employees = repository.GetEmployees();
            return Ok(employees);
        }
        [HttpGet("{id}")] 
        public IActionResult GetEmployee(int id)
        { 
            var employee = repository.GetEmployeeById(id);
            if (employee == null) { return NotFound(); 
            } 
            return Ok(employee);
        }


        [HttpPost("create")]
        [Route("employees/add")]
        public IActionResult CreateEmployee([FromBody] Employee employee) 
        {

            if (employee == null)
            {
                return BadRequest(); 
            } 
            repository.AddEmployee(employee);
            return CreatedAtAction(nameof(GetEmployee), new { id = employee.EmployeeId }, employee); 
        }
        [HttpPut("{id}")] 
        public IActionResult UpdateEmployee(int id, [FromBody] Employee employee) 
        { 
            if (employee == null || id != employee.EmployeeId)
            { 
                return BadRequest();
            } 
            var existingEmployee = repository.GetEmployeeById(id);
            if (existingEmployee == null)
            {
                return NotFound(); 
            } 
            repository.EditEmployee(employee);
            return NoContent();
        }
        [HttpDelete("{id}")] 
        public IActionResult DeleteEmployee(int id) 
        {
            var employee = repository.GetEmployeeById(id); 
            if (employee == null)
            {
                return NotFound(); 
            }
            repository.DeleteEmployee(id); return NoContent(); 
        }
        [HttpGet("department/{departmentId}")] 
        public IActionResult GetEmployeesByDepartmentId(int departmentId) 
        { 
            var employees = repository.GetEmployeesByDepartmentId(departmentId);
            return Ok(employees);
        }
       
    }
}
